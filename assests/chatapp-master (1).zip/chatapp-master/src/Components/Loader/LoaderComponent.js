import React from 'react';
import './LoaderComponent.css'

const LoaderComponent = (props => {
    return (
        <div className="loader"></div>
    );
})

export default LoaderComponent;